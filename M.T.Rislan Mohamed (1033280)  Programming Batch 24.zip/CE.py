import streamlit as st

# --- Data (Replace with your actual database or data structures) ---
products = {
    "Laptop": {"price": 120000.00},
    "Smartphone": {"price": 80000.00},
    "Tablet": {"price": 30000.00},
    "Headphones": {"price": 1150.00},
}

users = {
    "rislan": {"password": "rishi1033280"}  # Pre-added user
}

orders = []  # In a real application, this would be a database for orders

# --- Helper Functions ---
def calculate_total(cart):
    total = 0
    for item, quantity in cart.items():
        if item in products:
            total += products[item]["price"] * quantity
    return total

# --- User Authentication ---
def register_user():
    st.subheader("Customer Registration")
    new_username = st.text_input("New Username")
    new_password = st.text_input("New Password", type="password")
    if st.button("Register"):
        if new_username and new_password:
            if new_username not in users:
                users[new_username] = {"password": new_password}
                st.success(f"User '{new_username}' registered successfully! Please log in.")
            else:
                st.error("Username already exists. Please choose a different one.")
        else:
            st.warning("Please enter both username and password.")

def login(username, password):
    if username in users and users[username]["password"] == password:
        return True
    return False

# --- Admin Section ---
def admin_login():
    st.subheader("Admin Login")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    if st.button("Login"):
        if username == "admin" and password == "admin":
            st.session_state.logged_in_as = "admin"
            st.success("Admin login successful!")
        else:
            st.error("Invalid credentials.")

def admin_dashboard():
    st.subheader("Admin Dashboard")

    st.subheader("Product Management")
    col1, col2, col3 = st.columns(3)
    with col1:
        add_product_name = st.text_input("Add Product")
    with col2:
        add_product_price = st.number_input("Price", min_value=0.0)
    with col3:
        if st.button("Add"):
            if add_product_name and add_product_name not in products:
                products[add_product_name] = {"price": add_product_price}
                st.success(f"'{add_product_name}' added.")
            elif add_product_name in products:
                st.warning(f"'{add_product_name}' already exists.")
            else:
                st.warning("Please enter a product name.")

    st.subheader("Modify/Remove Products")
    selected_product = st.selectbox("Select Product", list(products.keys()))
    col1_mod, col2_mod = st.columns(2)
    with col1_mod:
        new_price = st.number_input("New Price", min_value=0.0, value=products[selected_product]["price"])
        if st.button("Update Price"):
            products[selected_product]["price"] = new_price
            st.success(f"'{selected_product}' price updated to {new_price}.")
    with col2_mod:
        if st.button("Remove Product"):
            del products[selected_product]
            st.success(f"'{selected_product}' removed.")

    st.subheader("Customer Orders")
    if orders:
        for i, order in enumerate(orders):
            st.markdown(f"**Order #{i+1}**")
            st.write(f"Customer: {order['customer']}")
            st.write("Items:")
            for item, quantity in order["cart"].items():
                st.write(f"- {item}: {quantity}")
            st.write(f"Total: ${order['total']:.2f}")
            st.write(f"Status: {order['status']}")
            new_status = st.selectbox("Update Status", ["Pending", "Processing", "Shipped", "Delivered"],
                                      index=["Pending", "Processing", "Shipped", "Delivered"].index(order['status']),
                                      key=f"status_{i}")
            if st.button("Update", key=f"update_{i}"):
                order['status'] = new_status
                st.success(f"Order #{i+1} status updated to '{new_status}'.")
            st.divider()
    else:
        st.info("No customer orders yet.")

# --- Customer Section ---
def customer_login():
    st.subheader("Customer Login")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    if st.button("Login"):
        if username and password and login(username, password):
            st.session_state.logged_in_as = username
            st.session_state.cart = st.session_state.get("cart", {})
            st.success(f"Logged in as {username}!")
        else:
            st.error("Invalid username or password.")
    st.markdown("Don't have an account? [Register here](#customer-registration)")

def customer_dashboard():
    st.subheader(f"Welcome, {st.session_state.logged_in_as}!")

    st.subheader("Available Electronic Devices")
    for product, details in products.items():
        st.write(f"- **{product}**: ${details['price']:.2f}")
        quantity = st.number_input(f"Quantity for {product}", min_value=0, key=f"qty_{product}")
        if quantity > 0:
            st.session_state.cart[product] = quantity
        elif product in st.session_state.cart:
            del st.session_state.cart[product]

    st.subheader("Your Cart")
    if st.session_state.get("cart"):
        for item, quantity in st.session_state.cart.items():
            st.write(f"- {item}: {quantity}")
        total_amount = calculate_total(st.session_state.cart)
        st.markdown(f"**Total Payment Amount: ${total_amount:.2f}**")
        if st.button("Place Order"):
            new_order = {
                "customer": st.session_state.logged_in_as,
                "cart": st.session_state.cart.copy(),
                "total": total_amount,
                "status": "Pending",
            }
            orders.append(new_order)
            st.session_state.cart = {}
            st.success("Order placed successfully!")
    else:
        st.info("Your cart is empty.")

# --- Main Application ---
def main():
    st.title("City Electronic Store")

    if "logged_in_as" not in st.session_state:
        option = st.sidebar.radio("Login As", ["Customer", "Admin"])
        if option == "Admin":
            admin_login()
        elif option == "Customer":
            login_option = st.sidebar.radio("Customer Options", ["Login", "Register"])
            if login_option == "Login":
                customer_login()
            elif login_option == "Register":
                register_user()
    elif st.session_state.logged_in_as == "admin":
        if st.sidebar.button("Logout"):
            del st.session_state.logged_in_as
            st.rerun()
        admin_dashboard()
    elif st.session_state.logged_in_as:
        if st.sidebar.button("Logout"):
            del st.session_state.logged_in_as
            st.session_state.cart = {}
            st.rerun()
        customer_dashboard()

if __name__ == "__main__":
    main()
