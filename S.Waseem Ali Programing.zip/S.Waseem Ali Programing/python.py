import streamlit as st

st.set_page_config(page_title="City Electronics", layout="centered")

# Page navigation
menu = st.sidebar.selectbox("Navigation", ["Home", "Register", "Login", "Admin Login"])

# Header
st.title("🔌 City Electronics")

# Registration Page
if menu == "Register":
    st.subheader("Create an Account")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")

    if st.button("Register"):
        if not username or not password:
            st.warning("Please fill in all fields.")
        else:
            st.success("Registration successful!")

# Login Page
elif menu == "Login":
    st.subheader("User Login")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")

    if st.button("Login"):
        st.success(f"Welcome back, {username}!")

# Admin Login Page
elif menu == "Admin Login":
    st.subheader("Admin Login")
    admin_user = st.text_input("Admin Username")
    admin_pass = st.text_input("Admin Password", type="password")

    if st.button("Admin Login"):
        st.success("Admin access granted.")
        st.info("You are logged in as Admin.")

# Home Page
else:
    st.write("Welcome to **City Electronics**!")
    st.image("https://cdn.pixabay.com/photo/2016/03/09/09/30/technology-1242280_1280.jpg", use_column_width=True)
    st.markdown("""
    Explore and manage electronics easily with our simple login system.
    - Register and login as a user
    - Admin can log in separately
    """)
